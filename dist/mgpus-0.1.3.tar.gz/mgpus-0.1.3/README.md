# mgpus



## Installation

```bash
pip install mgpus
```
